<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-1">
        <div class="breadcrumbs text-sm">
            <ul>
                <li><a href="<?php echo e(route('admin.beranda')); ?>">Beranda</a></li>
                <li>Mahasiswa</li>
            </ul>
        </div>
        <div>
            <div class="card card-border bg-base-100 w-full shadow">
                <div class="card-body">
                    <div class="flex justify-between">
                        <h2 class="card-title">Mahasiswa</h2>

                        
                        <form action="<?php echo e(route('admin.mahasiswa')); ?>" method="get">
                            <div class="flex">
                                <select class="select" name="id_pengguna">
                                    <option value="" <?php echo e($id_pengguna ? '' : 'selected'); ?>>Semua</option>
                                    <?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->hasRole('user')): ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php echo e($id_pengguna == $item->id ? 'selected' : ''); ?>>
                                                <?php echo e($item->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-primary">Cari</button>
                            </div>
                        </form>
                    </div>
                    <div class="overflow-x-auto rounded-md border border-base-content/5 bg-base-100 p-2">
                        <table class="table" id="myTable">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>NAC</th>
                                    <th>No. Hp</th>
                                    <th>Kab/Kota</th>
                                    <th>Sistem paket</th>
                                    <th>PJW</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->nac); ?></td>
                                        <td><?php echo e($item->no_hp); ?></td>
                                        <td><?php echo e($item->kab_kota); ?></td>
                                        <td><?php echo e($item->sistem_paket); ?></td>
                                        <td><?php echo e($item->users->name); ?></td>
                                        <td>
                                            <h7 class="bg-success p-1 rounded-full text-white">
                                                Status
                                            </h7>
                                        </td>
                                        <td>aksi</td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\@Malam\Laravel\Project\@Ita Fina\periksa_kerjaan\resources\views/admin/mahasiswa/index.blade.php ENDPATH**/ ?>