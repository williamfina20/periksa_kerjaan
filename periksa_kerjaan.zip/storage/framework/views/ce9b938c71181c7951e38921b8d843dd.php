<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-1">
        <div class="breadcrumbs text-sm">
            <ul>
                <li><a href="<?php echo e(route('user.beranda')); ?>">Beranda</a></li>
                <li><a href="<?php echo e(route('user.mahasiswa')); ?>">Mahasiswa</a></li>
                <li>Edit Mahasiswa</li>
            </ul>
        </div>
        <div>
            <div class="card card-border bg-base-100 w-full shadow">
                <div class="card-body">
                    <h2 class="card-title">Edit Mahasiswa</h2>
                    <form action="<?php echo e(route('user.mahasiswa.update', $mahasiswa->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <fieldset class="fieldset mb-2">
                            <legend class="fieldset-legend">Nama</legend>
                            <input type="text" name="nama" class="input w-full" placeholder="Type here"
                                value="<?php echo e($mahasiswa->nama); ?>" />
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="label text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </fieldset>
                        <fieldset class="fieldset mb-2">
                            <legend class="fieldset-legend">NAC</legend>
                            <input type="text" name="nac" class="input w-full" placeholder="Type here"
                                value="<?php echo e($mahasiswa->nac); ?>" />
                            <?php $__errorArgs = ['nac'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="label text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </fieldset>
                        <fieldset class="fieldset mb-2">
                            <legend class="fieldset-legend">No Hp</legend>
                            <input type="number" name="no_hp" class="input w-full" placeholder="Type here"
                                value="<?php echo e($mahasiswa->no_hp); ?>" />
                            <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="label text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </fieldset>
                        <fieldset class="fieldset mb-2">
                            <legend class="fieldset-legend">Kab/Kota</legend>
                            <select class="select w-full" name="kab_kota">
                                <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item); ?>" <?php if($item == $mahasiswa->kab_kota): ?> selected <?php endif; ?>>
                                        <?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['kab_kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="label text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </fieldset>
                        <fieldset class="fieldset mb-2">
                            <legend class="fieldset-legend">Sistem Paket</legend>
                            <select class="select w-full" name="sistem_paket">
                                <option value="Sipas" <?php if($mahasiswa->sistem_paket == 'Sipas'): ?> selected <?php endif; ?>>Sipas</option>
                                <option value="Non-Sipas" <?php if($mahasiswa->sistem_paket == 'Non-Sipas'): ?> selected <?php endif; ?>>Non-Sipas
                                </option>
                            </select>
                            <?php $__errorArgs = ['sistem_paket'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="label text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </fieldset>
                        <div class="mb-2 flex justify-end">
                            <a href="<?php echo e(route('user.mahasiswa')); ?>" class="btn btn-secondary me-1">Kembali</a>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\@Malam\Laravel\Project\@Ita Fina\periksa_kerjaan\resources\views/user/mahasiswa/edit.blade.php ENDPATH**/ ?>